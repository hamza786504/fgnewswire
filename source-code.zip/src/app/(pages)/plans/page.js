import React from 'react'

function Plans() {
  return (
    <>
      
    </>
  )
}

export default Plans
