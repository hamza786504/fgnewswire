import React from 'react'
import PackagesWithAllFilters from '../Componenets/Filters'

function Sites() {
  return (
    <div>
            <PackagesWithAllFilters />
      
    </div>
  )
}

export default Sites
