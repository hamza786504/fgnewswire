import React from 'react'

function Content({ content }) {

    return (
        <>
            {content}
        </>
    )
}

export default Content
